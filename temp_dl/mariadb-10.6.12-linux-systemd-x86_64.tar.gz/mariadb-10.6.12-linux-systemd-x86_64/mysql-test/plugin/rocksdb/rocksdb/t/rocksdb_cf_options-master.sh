#!/bin/bash

cat > $MYSQL_TMP_DIR/cf_configs.cnf <<EOL

EOL
