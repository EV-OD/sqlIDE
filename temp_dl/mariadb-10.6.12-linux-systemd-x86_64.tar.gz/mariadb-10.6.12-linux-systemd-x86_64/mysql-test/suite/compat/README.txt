To run a test suite under this directory, you should use the format:

mysql-test-run --suite=compat/oracle

or to run one test:

mysql-test-run compat/oracle.test_name
